var JSCore = (function(){

	var JSCore = {};
	JSCore.ext = {
	};
	
	JSCore.ext.utils = {
	};
	
	JSCore.ext.mvp = {
	};
	