define(function() {
	
	return {
		secondExtensionFunction: function(input) {
			console.log("From secondExtension: " + input);
		}
	}
});