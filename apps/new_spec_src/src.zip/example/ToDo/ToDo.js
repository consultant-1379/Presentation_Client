define([
	"core", 
	"../regions/FormRegion/FormRegion",
	"../regions/ListRegion/ListRegion",
], function(Core, FormRegion, ListRegion) { 

	return Core.App.extend({
	
		template: "./template.html",
		style: "./style.css",
		
		routes: {
			"active" : 'showActive',
			"completed" : 'showCompleted'
		},
	
		init: function() {
			this.formRegion = new FormRegion(); 
			this.listRegion = new ListRegion();
			
			f.router.initialise(this.routes);
			
			f.router.on("route:showActive"), function() {
				this.formRegion.showActive();
			});
			
			f.router.on("route:showCompleted"), function() {
				this.formRegion.showCompleted();
			});
			
			f.setUrl("showActive"); // doesn't activate anything?
			f.navigate("showActive"); // activates the callback
	
		},
		
		start: function(element)
		{
			this._super("start", element);
			var formElem = document.getElementById("form");
			this.formRegion.start(formElem);
			
			var listElem = document.getElementById("list");
			this.listRegion.start(listElem);
		},
	});

});